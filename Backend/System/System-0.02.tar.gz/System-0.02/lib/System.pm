package System;
use strict;
use warnings FATAL => 'all';

our $VERSION = '0.02';
1;